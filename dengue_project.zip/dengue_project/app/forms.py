# from django import forms

# class ClusterForm(forms.Form):
#     s_res = forms.FloatField(label='S_res', required=True)
#     t_res = forms.FloatField(label='T_res', required=True)


from django import forms

class ClusterForm(forms.Form):
    s_res = forms.FloatField(label='S_res', required=True)
    t_res = forms.FloatField(label='T_res', required=True)
