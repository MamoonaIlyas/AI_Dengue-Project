# # app/views.py
# from django.shortcuts import render

# def index(request):
#     return render(request, 'app/index.html')  # Correct the path of the template


from django.shortcuts import render
from .forms import ClusterForm
from kmeans_model import predict_cluster

def index(request):
    cluster = None
    if request.method == "POST":
        form = ClusterForm(request.POST)
        if form.is_valid():
            s_res = form.cleaned_data['s_res']
            t_res = form.cleaned_data['t_res']
            cluster = predict_cluster(s_res, t_res)
    else:
        form = ClusterForm()

    return render(request, 'app/index.html', {'form': form, 'cluster': cluster})

