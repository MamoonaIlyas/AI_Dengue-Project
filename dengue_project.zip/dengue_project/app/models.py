from django.db import models

# Create your models here.

class DengueCase(models.Model):
    location = models.CharField(max_length=100)
    year = models.IntegerField()
    total_cases = models.IntegerField()
    case_definition_standardised = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.location} - {self.year}"


