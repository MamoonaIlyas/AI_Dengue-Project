import pandas as pd
from sklearn.cluster import KMeans

# Load data
df = pd.read_csv('encoder.csv')

# Train KMeans
kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(df[['S_res_encoded', 'T_res_encoded']])

def predict_cluster(s_res, t_res):
    return kmeans.predict([[s_res, t_res]])[0]
